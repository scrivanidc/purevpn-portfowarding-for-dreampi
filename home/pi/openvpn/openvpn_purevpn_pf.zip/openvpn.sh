#!/bin/bash

sudo systemctl stop dreampi

python /home/pi/dreampi/dreampi_1.9.py --no-daemon &

echo "wait 45 seconds until dreampi legacy code starts ..."
sleep 45

sudo killall openvpn

echo "starting purevpn ..."
sleep 3

sudo openvpn --config /home/pi/"$1".ovpn --auth-user-pass pass &
sleep 10

sudo iptables -t nat -D POSTROUTING -o tun0 -j MASQUERADE
sudo iptables -t nat -A POSTROUTING -o tun0 -j MASQUERADE

sleep 3

sudo iptables -t nat -D PREROUTING -i tun0 -j DNAT --to-destination 192.168.0.98
sudo iptables -t nat -A PREROUTING -i tun0 -j DNAT --to-destination 192.168.0.98

sudo service dcdaytona restart &
sudo service dc2k2 restart &
sudo service dcgamespy restart &
sudo service dcvoip restart &

sudo iptables -t nat -L -n -v

sudo curl ipinfo.io

exit 0
