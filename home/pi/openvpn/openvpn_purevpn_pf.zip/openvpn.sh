#!/bin/bash

sudo systemctl stop dreampi.service
sudo systemctl stop remote_bba_mode.service
sudo killall openvpn

sudo service dcdaytona stop &
sudo service dc2k2 stop &
sudo service dcgamespy stop &
sudo service dcvoip stop &

sudo pkill -f dreampi_1.9.py
sudo python /home/pi/dreampi/dreampi_1.9.py --no-daemon &

echo ">>> Wait 30 seconds until dreampi legacy code starts ..."
sleep 27

echo ">> Starting PureVPN for Dreamcast ..."
sleep 3

sudo openvpn --config /home/pi/"$1".ovpn --auth-user-pass pass &
sleep 10

sudo iptables -t nat -D POSTROUTING -o tun0 -j MASQUERADE
sudo iptables -t nat -A POSTROUTING -o tun0 -j MASQUERADE

sleep 3

sudo iptables -t nat -D PREROUTING -i tun0 -j DNAT --to-destination 192.168.0.98
sudo iptables -t nat -A PREROUTING -i tun0 -j DNAT --to-destination 192.168.0.98

sudo service dcdaytona restart &
sudo service dc2k2 restart &
sudo service dcgamespy restart &
sudo service dcvoip restart &

sudo iptables -t nat -L -n -v

sudo curl ipinfo.io

exit 0
